#pragma once

#define HTTP_SERVER "103.149.252.178"
#define HTTP_PORT 80

#define TFTP_SERVER "103.149.252.178"
